package com.inducesmile.backupdatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.inducesmile.backupdatabase.gDriveBackUp.GDriveUpload;

import java.io.File;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("BackUp To GDriveUpload");

        Button backUpBtn = (Button)findViewById(R.id.backup_data);
        backUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GDriveUpload uploadData = new GDriveUpload(MainActivity.this);
                uploadData.saveFileToDrive(new File(""));
            }
        });
    }
}
