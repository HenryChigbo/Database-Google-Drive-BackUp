package com.inducesmile.backupdatabase.gDriveBackUp;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.google.android.gms.drive.CreateFileActivityOptions;
import com.google.android.gms.drive.DriveClient;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveResourceClient;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.tasks.Task;
import com.inducesmile.backupdatabase.utils.DatabaseUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;


public class GDriveUpload {

    private static final String TAG = GDriveUpload.class.getSimpleName();

    private Context context;

    private DriveClient driveClient;
    private DriveResourceClient driveResourceClient;

    private static final int REQUEST_CODE_CREATOR = 2;
    private static final int REQUEST_CODE_CREATE_FILE = 3;


    public GDriveUpload(Context context) {
        this.context = context;
    }


    /** Create a new file and save it to Drive. */
    public void saveFileToDrive(File file) {
        // Start by creating a new contents, and setting a callback.
        Log.i(TAG, "Creating new contents.");

        driveResourceClient
                .createContents()
                .continueWithTask(task -> createFileIntentSender(task.getResult(), file))
                .addOnFailureListener(
                        e -> Log.w(TAG, "Failed to create new contents.", e));
    }


    public Task<Void> createFileIntentSender(DriveContents driveContents, File file){

        Log.i(TAG, "New contents created.");
        // Get an output stream for the contents.
        OutputStream outputStream = driveContents.getOutputStream();
        // Write the bitmap data from it.
        ByteArrayOutputStream bitmapStream = new ByteArrayOutputStream();
        //image.compress(Bitmap.CompressFormat.PNG, 100, bitmapStream);

        //***** file to binary here *******//
        try {
            outputStream.write(bitmapStream.toByteArray());
        } catch (IOException e) {
            Log.w(TAG, "Unable to write file contents.", e);
        }

        // Create the initial metadata - MIME type and title.
        // Note that the user will be able to change the title later.
        MetadataChangeSet metadataChangeSet =
                new MetadataChangeSet.Builder()
                        .setMimeType(DatabaseUtils.MIME_TYPE)
                        .setTitle(DatabaseUtils.DATABASE_TITLE)
                        .setStarred(true)
                        .build();

        // Set up options to configure and display the create file activity.
        CreateFileActivityOptions createFileActivityOptions =
                new CreateFileActivityOptions.Builder()
                        .setInitialMetadata(metadataChangeSet)
                        .setInitialDriveContents(driveContents)
                        .build();


        return driveClient
                .newCreateFileActivityIntentSender(createFileActivityOptions)
                .continueWith(task -> {((Activity)context).startIntentSenderForResult(task.getResult(), REQUEST_CODE_CREATOR, null, 0, 0, 0);
                    return null;
                });
    }
}
